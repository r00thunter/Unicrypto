<?php
define('BASE_URL', 'http://54.186.144.84/');

?>