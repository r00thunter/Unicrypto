<?php
session_start();
session_destroy();
header('Location: http://54.186.144.84/api/admin/login.php');
?>