<?php

/**
* 
*/
class error 
{
	
	function __construct(argument)
	{
		# code...
	}

	public static function error_display($value='')
	{
		# code...
	}
}