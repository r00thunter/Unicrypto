<?php

// database constants
define('HOST', 'localhost');
define('DB', 'referral');
define('DB_USER', 'root');
define('DB_PASS', 'xchange123');

// general constants
define('ONE', 1);
define('ZERO', 0);
?>
